module MainPageHelper
end
