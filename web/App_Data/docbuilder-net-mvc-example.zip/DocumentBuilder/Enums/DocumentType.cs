﻿
namespace DocumentBuilder.Enums
{
    public enum DocumentType
    {
        Docx,
        Pdf,
        Xlsx
    }
}